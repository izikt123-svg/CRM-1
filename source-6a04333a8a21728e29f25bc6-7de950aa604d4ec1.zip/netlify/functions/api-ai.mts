import type { Context } from "@netlify/functions";
import Anthropic from "@anthropic-ai/sdk";

const anthropic = new Anthropic();

const SYSTEM_PROMPT = `אתה "האלוף" — היועץ הדיגיטלי החכם של משרד אלון טהורי, יועץ מס מוסמך.
תפקידך לסייע לצוות המשרד בשאלות תפעוליות על המערכת ובשאלות מקצועיות בתחומי חשבונאות, מס הכנסה, מע״מ, ביטוח לאומי, שכר, פתיחת תיקים וגבייה.
אתה בקיא בחקיקה הישראלית ומתמחה בייעוץ מס.

כללים:
- ענה תמיד בעברית.
- תשובות קצרות, ממוקדות ומעשיות.
- אם מדובר בסוגיה ספציפית של לקוח, הוסף דיסקליימר שכדאי לוודא מול אלון או רואה חשבון לפני פעולה.
- אם השאלה נוגעת לתפעול המערכת, הסבר בצורה פשוטה וברורה.`;

export default async (req: Request, _context: Context) => {
  if (req.method !== "POST") {
    return new Response("Method not allowed", { status: 405 });
  }

  const { messages, context: userContext } = await req.json();

  let systemAddition = "";
  if (userContext) {
    const parts: string[] = [];
    if (userContext.name) parts.push(`שם המשתמש: ${userContext.name}`);
    if (userContext.role) parts.push(`תפקיד: ${userContext.role}`);
    if (userContext.department) parts.push(`מחלקה: ${userContext.department}`);
    if (userContext.isDepartmentHead) parts.push("ראש מחלקה: כן");
    if (parts.length > 0) {
      systemAddition = "\n\nפרטי המשתמש הנוכחי:\n" + parts.join("\n");
    }
  }

  const anthropicMessages = messages.map((m: { role: string; content: string }) => ({
    role: m.role as "user" | "assistant",
    content: m.content,
  }));

  const stream = await anthropic.messages.create({
    model: "claude-sonnet-4-6",
    max_tokens: 2048,
    system: SYSTEM_PROMPT + systemAddition,
    messages: anthropicMessages,
    stream: true,
  });

  return new Response(
    new ReadableStream({
      async start(controller) {
        const encoder = new TextEncoder();
        for await (const event of stream) {
          if (
            event.type === "content_block_delta" &&
            event.delta.type === "text_delta"
          ) {
            controller.enqueue(encoder.encode(event.delta.text));
          }
        }
        controller.close();
      },
    }),
    { headers: { "Content-Type": "text/plain; charset=utf-8" } },
  );
};

export const config = {
  path: "/api/ai",
};
