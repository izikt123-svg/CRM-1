import type { Context } from "@netlify/functions";
import { getStore } from "@netlify/blobs";

const STORE_NAME = "tahori-state";
const STATE_KEY = "app-state";

export default async (req: Request, _context: Context) => {
  const store = getStore({ name: STORE_NAME, consistency: "strong" });

  if (req.method === "GET") {
    const state = await store.get(STATE_KEY, { type: "json" });
    if (!state) {
      return Response.json({});
    }
    return Response.json(state);
  }

  if (req.method === "PUT") {
    const body = await req.json();
    await store.setJSON(STATE_KEY, body);
    return new Response("ok", { status: 200 });
  }

  return new Response("Method not allowed", { status: 405 });
};

export const config = {
  path: "/api/state",
};
