(function() {
  'use strict';

  function clickTab(tabName) {
    var buttons = document.querySelectorAll('button.tab, button[type="button"]');
    for (var i = 0; i < buttons.length; i++) {
      var btn = buttons[i];
      var text = btn.textContent || '';
      if (tabName === 'tasks' && text.includes('המשימות')) { btn.click(); return; }
      if (tabName === 'calendar' && text.includes('לוח שנה')) { btn.click(); return; }
      if (tabName === 'attendance' && text.includes('שעון נוכחות')) { btn.click(); return; }
      if (tabName === 'messages' && text.includes('הודעות')) { btn.click(); return; }
      if (tabName === 'workers' && text.includes('עובדים')) { btn.click(); return; }
      if (tabName === 'archive' && text.includes('ארכיון')) { btn.click(); return; }
      if (tabName === 'clients' && text.includes('תיקי לקוחות')) { btn.click(); return; }
      if (tabName === 'leads' && text.includes('פנקס לידים') || tabName === 'leads' && text.includes('לידים')) { btn.click(); return; }
      if (tabName === 'audit' && text.includes('יומן פעילות')) { btn.click(); return; }
      if (tabName === 'vacation' && text.includes('חופש')) { btn.click(); return; }
    }
  }

  var menus = [
    {
      emoji: '📋',
      label: 'ניהול משימות',
      items: [
        { emoji: '📋', title: 'רשימת משימות', desc: 'צפייה, עדכון סטטוס, יצירת משימות חדשות ומעקב אחרי התקדמות', tab: 'tasks', badge: 'כלי ראשי', badgeColor: 'blue' },
        { emoji: '📅', title: 'לוח שנה', desc: 'תצוגה יומית, שבועית וחודשית של כל המשימות והדדליינים', tab: 'calendar' },
        { emoji: '🗄️', title: 'ארכיון משימות', desc: 'משימות שהושלמו — חיפוש, ייצוא, שחזור והיסטוריה מלאה', tab: 'archive' }
      ]
    },
    {
      emoji: '👥',
      label: 'צוות ועובדים',
      items: [
        { emoji: '👥', title: 'עובדים וביצועים', desc: 'ניהול עובדים, ציונים, מחלקות, הרשאות ודוחות ביצועים', tab: 'workers', badge: 'ניהול', badgeColor: 'purple' },
        { emoji: '⏰', title: 'שעון נוכחות', desc: 'כניסה/יציאה, הפסקות, חופשות ודוח נוכחות שבועי וחודשי', tab: 'attendance' },
        { emoji: '🌴', title: 'ניהול חופשות', desc: 'בקשות חופשה, אישורים, דחיות ומעקב ימי חופש', tab: 'vacation' }
      ]
    },
    {
      emoji: '🗂️',
      label: 'לקוחות ולידים',
      items: [
        { emoji: '🗂️', title: 'תיקי לקוחות', desc: 'ניהול לקוחות — פרטים, תגיות VIP, קוד לקוח, הערות ומשימות קשורות', tab: 'clients', badge: 'CRM', badgeColor: 'green' },
        { emoji: '📞', title: 'פנקס לידים', desc: 'מעקב אחרי לידים נכנסים — מקור, סטטוס, המרה ללקוח ויצירת משימה', tab: 'leads' }
      ]
    },
    {
      emoji: '💬',
      label: 'תקשורת ומעקב',
      items: [
        { emoji: '💬', title: 'הודעות פנימיות', desc: 'הודעות בין עובדים ומנהלים — תקשורת פנימית, הודעות קוליות ושליחה לכולם', tab: 'messages', badge: 'צ\'אט', badgeColor: 'blue' },
        { emoji: '📜', title: 'יומן פעילות', desc: 'תיעוד כל הפעולות במערכת — מי עשה מה ומתי, שקיפות מלאה', tab: 'audit' }
      ]
    },
    {
      emoji: '🛠️',
      label: 'כלים נוספים',
      items: [
        { emoji: '🔥', title: 'משימות דחופות', desc: 'צפייה מהירה בכל המשימות עם דחיפות גבוהה שעדיין פתוחות', action: 'urgentFilter' },
        { emoji: '📊', title: 'סיכום ביצועים', desc: 'סטטיסטיקות משרדיות — ציוני עובדים, קצב ביצוע ומדדי KPI', action: 'kpiView' },
        { emoji: '💙', title: 'רווחת עובדים', desc: 'מעקב רווחה — פינגים של עובדים שצריכים תשומת לב אנושית', action: 'wellbeing' },
        { sep: true },
        { emoji: '📖', title: 'ברכת השראה יומית', desc: 'ברכה והשראה מהמקורות היהודיים לפתיחת יום עבודה מוצלח', action: 'blessing' }
      ]
    }
  ];

  function buildMenu() {
    var nav = document.createElement('nav');
    nav.className = 'mega-nav';
    nav.setAttribute('aria-label', 'תפריט ראשי');

    var inner = document.createElement('div');
    inner.className = 'mega-nav-inner';

    menus.forEach(function(menu) {
      var item = document.createElement('div');
      item.className = 'mega-nav-item';

      var btn = document.createElement('button');
      btn.className = 'mega-nav-btn';
      btn.type = 'button';
      btn.innerHTML = '<span class="nav-emoji">' + menu.emoji + '</span>' +
        '<span class="nav-label">' + menu.label + '</span>' +
        '<span class="nav-arrow">▼</span>';

      var dropdown = document.createElement('div');
      dropdown.className = 'mega-dropdown' + (menu.items.length > 3 ? ' wide' : '');

      var header = document.createElement('div');
      header.className = 'mega-dropdown-header';
      header.innerHTML = '<span class="mega-dropdown-header-icon">' + menu.emoji + '</span>' +
        '<span class="mega-dropdown-header-text">' + menu.label + '</span>';
      dropdown.appendChild(header);

      menu.items.forEach(function(link) {
        if (link.sep) {
          var sep = document.createElement('div');
          sep.className = 'mega-sep';
          dropdown.appendChild(sep);
          return;
        }

        var a = document.createElement('div');
        a.className = 'mega-link';
        a.setAttribute('role', 'button');
        a.setAttribute('tabindex', '0');

        var badgeHtml = '';
        if (link.badge) {
          badgeHtml = '<span class="mega-badge mega-badge-' + (link.badgeColor || 'blue') + '">' + link.badge + '</span>';
        }

        a.innerHTML = '<div class="mega-link-icon">' + link.emoji + '</div>' +
          '<div class="mega-link-text">' +
          '<div class="mega-link-title">' + link.title + badgeHtml + '</div>' +
          '<div class="mega-link-desc">' + link.desc + '</div>' +
          '</div>';

        a.addEventListener('click', function() {
          if (link.tab) {
            clickTab(link.tab);
          } else if (link.action === 'urgentFilter') {
            clickTab('tasks');
            setTimeout(function() {
              var searchInput = document.querySelector('input[placeholder*="חיפוש"]');
              if (searchInput) {
                var nativeInputValueSetter = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, 'value').set;
                nativeInputValueSetter.call(searchInput, 'דחוף');
                searchInput.dispatchEvent(new Event('input', { bubbles: true }));
              }
            }, 300);
          } else if (link.action === 'kpiView') {
            clickTab('workers');
          } else if (link.action === 'wellbeing') {
            clickTab('workers');
          } else if (link.action === 'blessing') {
            window.scrollTo({ top: 0, behavior: 'smooth' });
          }
        });

        a.addEventListener('keydown', function(e) {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            a.click();
          }
        });

        dropdown.appendChild(a);
      });

      item.appendChild(btn);
      item.appendChild(dropdown);
      inner.appendChild(item);
    });

    nav.appendChild(inner);
    return nav;
  }

  function inject() {
    if (document.querySelector('.mega-nav')) return;
    var body = document.body;
    if (!body || !body.firstChild) return;
    var nav = buildMenu();
    body.insertBefore(nav, body.firstChild);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function() {
      setTimeout(inject, 200);
    });
  } else {
    setTimeout(inject, 200);
  }
})();
